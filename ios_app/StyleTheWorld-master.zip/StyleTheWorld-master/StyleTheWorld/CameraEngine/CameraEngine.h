//
//  CameraEngine.h
//  CameraEngine
//
//  Created by Remi Robert on 12/02/16.
//  Copyright © 2016 Remi Robert. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CameraEngine.
FOUNDATION_EXPORT double CameraEngineVersionNumber;

//! Project version string for CameraEngine.
FOUNDATION_EXPORT const unsigned char CameraEngineVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CameraEngine/PublicHeader.h>


